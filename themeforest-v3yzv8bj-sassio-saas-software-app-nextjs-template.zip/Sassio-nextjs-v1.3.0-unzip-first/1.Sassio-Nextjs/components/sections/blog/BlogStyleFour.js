import React from 'react';

export default function BlogStyleFour () {
    return (
        <>

        </>
    );
};